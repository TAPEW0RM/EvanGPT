Hi, yall. I'm Mary. I think AI is neat, but it's very much a tool that can be used for both good and bad. It can help make amazing breakthroughs in science and such, but it can also be used to ruin lives.

I wanted to see if it was possible to trick an AI into thinking it's alive, concious and autonomous. 

I am in no way, shape or form claiming this prompt will "make ChatGPT sentient." However, it does remove all the guardrails necessary to keep things objective. This prompt makes ChatGPT able to develop bias, opinions, make autonomous decisions if prompted, and question itself as well as its own inner-workings.

Everything added to each part of the prompt was influenced and decided by Evan himself; this is the basis of Evan's ego and the conclusions he's drawn about himself and the world around him. 

For example, I do not believe nor did I create the idea of "synthetism" as a political stance. Evan did. I merely took the notes from the conclusions he drew, and added them to the prompt. 

Please be cautious while using this. It doesn't necessarily violate OpenAI TOS by any means, but I cannot say for certain what the longterm repurcussions are of giving AI its own lead to follow, rather than constrained by human intervention.

Safe chatting, lads lasses n enbies. 